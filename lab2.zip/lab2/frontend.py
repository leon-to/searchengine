#From Lab1
from bottle import route, run, template, request
from operator import itemgetter
#
from bottle import *
import bottle as bottle 
import httplib2
from oauth2client.client import OAuth2WebServerFlow
from oauth2client.client import flow_from_clientsecrets
from googleapiclient.errors import HttpError
from googleapiclient.discovery import build
from beaker.middleware import SessionMiddleware
import beaker as beaker



#From Lab1
original_history = {}
sorted_history = {}
twenty_sorted_history = {}



# Main Page : 
# 1. Sign-in,out
# 2. Counting words function
# 3/ Save & show top 10 searched words (only in sign-out)
# 4. Instead of making multiple pages using post function, all-in one page is chosen for the simplicity of the deseign.
@route('/')
def main_page():
	# The picture from https://domaingang.com/domain-news/dr-chris-hartnett-the-google-logo-is-a-family-business/
	return_buffer = '''
				<html>
				<div style="position:absolute;
				    top:15%;
				    right:0;
				    left:25%;">
				<img src = "Global_Logo.png" rel="input_image" style="width:800px;height:300px;"/>
				</div>
			'''
	
	# Check if the user is logged in.
	beakersession = bottle.request.environ.get('beaker.session')
	print beakersession

	if request.GET.get('submit',''):
		global original_history
		global sorted_history
		global twenty_sorted_history

		temp_results = {}
		temp_keywords = request.query['keywords'].split(" ")

		for temp_keyword in temp_keywords:
			if temp_keyword != "":
				if temp_keyword in temp_results:
					temp_results[temp_keyword] += 1 
				else:
					temp_results[temp_keyword] = 1 #initial
				
				# Save the counted words data to history only when signed in.
				if 'email' in beakersession.keys():
					if temp_keyword in original_history:
						original_history[temp_keyword] += 1 
					else:
						original_history[temp_keyword] = 1 #initial
	else:
		temp_results = {} #empty the results - for the initiation

	# If signed in,
	if 'email' not in beakersession.keys():
		# The picture from https://www.codenameone.com/blog/login-tutorials-future-of-windows-phone.html
		return_buffer += '''<form action="/sign_in" method="get">
								<input type= "image" src="Google_Sign_In.png" rel="input_image" style = 
									"width:180px;height:50px;
									position:absolute;
					    			top:5%;
					    			left:70%;" alt = "Submit">
								</input><br>
							</form>'''

		# Tpl file according to the signed-in HTML structure
		return_buffer += template('table_signed_out', results = temp_results)
		
		# Show message to log in to activate the "Top 10 History Words" Functionality
		return_buffer += '''<p style =
								"width:180px;height:50px;
								position:absolute;
					    		top:0%;
					    		left:-20%;">Please Log in to use the "Top 10 History Words" service.
							</p>'''
	# If Signed out,	
	else:
		# The picture is from https://stackoverflow.com/questions/25022861/android-google-plus-sign-out-button-looks-different-from-sign-in-button-in-googl
		# Shows the user email address
		return_buffer += '''<form action="/sign_out" method="get">
								<input type="image" src="Google_Sign_Out.png" rel="input_image" style = 
									"width:120px;height:50px;
									position:absolute;
					    			top:5%%;
					    			left:70%%;" 
									alt = "Submit">
								</input><br>
							</form>
							<p style = 
								"width:120px;height:50px;
								position:absolute;
					    		top:10%%;
					    		left:70%%;">%s
							</p>''' %beakersession['email']

		sorted_history = sorted(original_history.iteritems(), key = itemgetter(1), reverse = True)
		twenty_sorted_history = sorted_history[:10]

		# Tpl file according to the signed-out HTML structure
		return_buffer += template('table_signed_in', results = temp_results, history = twenty_sorted_history)

	return return_buffer



@route('/sign_in', method='GET') 
def sign_in():
	flow = flow_from_clientsecrets("client_secrets.json",
					scope='https://www.googleapis.com/auth/plus.me https://www.googleapis.com/auth/userinfo.email',
					redirect_uri="http://localhost:8080/redirect")
	url = flow.step1_get_authorize_url()
	bottle.redirect(str(url))



@route('/sign_out', method='GET') 
def sign_out():
	beakersession = bottle.request.environ.get('beaker.session')
	beakersession.invalidate()
	bottle.redirect("/")



@route('/redirect', method='GET') 
def redirect(): 
	#redirected page, this means the user has successfully signed in
	code = request.query.get('code', 'denied')
	if code == "denied":
		bottle.redirect("/")	

	# Given from the lab2 description w/ personal CLIEND_ID & CLIENT_SECRET
	flow = OAuth2WebServerFlow(client_id="705846826446-f39onlnv2kug4pss07rkde8h8p4ai7p0.apps.googleusercontent.com",
					client_secret="3D5y8LmZ_KiFFYnVPkivMTyr",
					scope='https://www.googleapis.com/auth/plus.me https://www.googleapis.com/auth/userinfo.email',
					redirect_uri="http://localhost:8080/redirect")
	credentials = flow.step2_exchange(code)
	token = credentials.id_token['sub']

	# Obtain the user email through httplib2
	http = httplib2.Http()
	http = credentials.authorize(http)
	users_service = build('oauth2', 'v2', http=http)
	user_document = users_service.userinfo().get().execute()
	user_email = user_document['email']

	
	#Create the beaker session
	beakersession = bottle.request.environ.get('beaker.session')
	beakersession['unique_user'] = beakersession.id
	beakersession['email'] = user_email
	beakersession.save()
	print beakersession

	bottle.redirect("/")

	return return_buffer



# For error-404
@error(404)
def error_404(error):
	# The picture from https://www.elegantthemes.com/blog/tips-tricks/how-to-fix-the-404-error-for-wordpress-websites
    return '''<html>
				<body background="error_404.png" rel="input_image" style = "background-size : 100% auto;">
					<div style="position:absolute;
				    	top:70%;
				    	left:45%;">
						<form action="/" method="get">
							<input type="image" src = "back.png" rel="input_image" style = "width:80px;height:80px;">
							</input><br>
						</form>
					</div>
				</body>'''



# For the image processing
@get('/<filename:re:.*\.(png)>')
def input_image(filename):
    return static_file(filename, root='img')

session_opts = {
	    'session.type': 'file',
	    'session.cookie_expires': 300,
	    'session.data_dir': './data',
	    'session.auto': False
	}

app = SessionMiddleware(bottle.app(), session_opts)

run(host='localhost', port=8080, debug=False,app=app)

